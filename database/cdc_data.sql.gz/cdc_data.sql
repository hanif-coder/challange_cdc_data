-- Adminer 4.8.1 MySQL 8.0.36-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `cdc_data`;
CREATE TABLE `cdc_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) DEFAULT NULL,
  `jurisdictionId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `startDate` varchar(100) DEFAULT NULL,
  `endDate` varchar(100) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `categoryType` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `vaccinationStatus` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `intent` varchar(255) DEFAULT NULL,
  `demographic` varchar(255) DEFAULT NULL,
  `difficultyReceivingVaccine` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `vaccinationWeek` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `vaccinationYear` int DEFAULT NULL,
  `vaccinationFrequency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `vaccinationPercentage` decimal(5,2) DEFAULT NULL,
  `vaccinationPercentageRange` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `totalVaccinations` int DEFAULT NULL,
  `vaccinationChange` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jurisdiction_id` (`jurisdictionId`),
  KEY `start_date` (`startDate`),
  KEY `end_date` (`endDate`),
  KEY `category` (`category`),
  KEY `vaccination_status` (`vaccinationStatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cdc_data` (`id`, `uuid`, `jurisdictionId`, `startDate`, `endDate`, `category`, `categoryType`, `vaccinationStatus`, `intent`, `demographic`, `difficultyReceivingVaccine`, `vaccinationWeek`, `vaccinationYear`, `vaccinationFrequency`, `vaccinationPercentage`, `vaccinationPercentageRange`, `totalVaccinations`, `vaccinationChange`) VALUES
(3,	'row-bgv9~icnj_5in8',	'00000000-0000-0000-F098-729374B64DDA',	'1970-01-01',	'1970-01-20',	NULL,	'1691095934',	NULL,	'{ }',	'National Estimates',	'National',	'Vaccination uptake and intention',	0,	'Difficulty Receiving COVID-19 Vaccine',	0.00,	'May 14 - May 20',	2023,	0.00),
(4,	'row-bgv9~icnj_5in8',	'00000000-0000-0000-F098-729374B64DDA',	'1970-01-01',	'1970-01-20',	NULL,	'1691095934',	NULL,	'{ }',	'National Estimates',	'National',	'Vaccination uptake and intention',	0,	'Difficulty Receiving COVID-19 Vaccine',	0.00,	'May 14 - May 20',	2023,	0.00),
(5,	'row-bgv9~icnj_5in8',	'00000000-0000-0000-F098-729374B64DDA',	'1970-01-01 00:00:00',	'1970-01-20 13:44:55',	NULL,	'1691095934',	NULL,	'{ }',	'National Estimates',	'National',	'Vaccination uptake and intention',	0,	'Difficulty Receiving COVID-19 Vaccine',	0.00,	'May 14 - May 20',	2023,	0.00),
(6,	'row-s9tq.i24j-23fj',	'00000000-0000-0000-0F83-7AB7B2F17B08',	'1970-01-01 00:00:00',	'1970-01-20 13:44:55',	NULL,	'1691095934',	NULL,	'{ }',	'Jurisdictional Estimates',	'Connecticut',	'All adults 18+',	0,	'Concern About COVID-19 Disease',	0.00,	'August 1 - August 28',	2021,	0.00);

-- 2024-02-21 11:32:12
